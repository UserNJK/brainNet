# BioNeuron — Biologically Accurate Spiking Neural Network

A from-scratch implementation of a cortical spiking neural network where each neuron operates on real biophysical principles — no backpropagation, no gradient descent. Learning is driven entirely by **Spike-Timing Dependent Plasticity (STDP)**, and connectivity is self-organized through **activity-dependent axon growth**.

---

## Core Architecture

**Leaky Integrate-and-Fire (LIF)**
Membrane dynamics with absolute refractory periods, excitatory/inhibitory synaptic conductances, and thermal noise injection. Dale's Law is enforced — 20% of neurons are GABAergic inhibitory, matching the actual cortical ratio. Each neuron also carries a **spike-frequency adaptation** current (an AHP/M-type K⁺ current; Brette & Gerstner 2005) so sustained drive produces the characteristic fast-then-slowing spike train rather than a fixed-rate train.

**STDP Learning**
Follows the Bi & Poo (1998) rule, implemented as an online all-to-all pair rule (Morrison et al. 2008): when the **pre**synaptic neuron fires *before* the postsynaptic one the synapse potentiates (LTP); the reverse order depresses it (LTD). No global error signal. No optimizer. Weights update purely from local spike timing. Dopamine scales the LTP amplitude (reward-modulated STDP).

**Growth Cone**
Each neuron periodically computes pairwise spike-train cross-correlations across the population and autonomously forms synapses toward neurons with correlated activity, modeling activity-dependent axon guidance. Synaptic pruning removes weights that decay below threshold, mirroring adolescent cortical pruning.

**Cell Assembly Detection**
Identifies emergent "thoughts" as synchronously firing neuron groups (Hebb, 1949) using co-firing correlation graphs and connected component analysis.

**Population Oscillations (LFP proxy)**
An `OscillationAnalyzer` treats the population firing rate as a local-field-potential proxy and reports its spectrum across the classic bands — delta / theta / alpha / beta / gamma — plus the dominant band, spectral peak, and how much of the signal is rhythmic vs broadband (Buzsáki & Draguhn 2004). This is the substrate for studying gamma/theta "binding."

**Homeostatic Plasticity** *(opt-in)*
Slow multiplicative scaling of each neuron's incoming synapses toward a target firing rate (Turrigiano & Nelson 2004), which keeps STDP from collapsing the network into silence or saturation.

**Short-Term Plasticity** *(opt-in)*
Per-axon facilitation and depression (Tsodyks–Markram; Mongillo et al. 2008): transmitted efficacy is `u·x`, where the utilization `u` facilitates and the resource pool `x` depletes on each spike, both recovering between spikes. Synaptic facilitation is the modern mechanism for working memory without persistent spiking — the substrate for the attractor-dynamics roadmap item.

**NMDA Receptors** *(opt-in)*
A second, slow excitatory conductance with Mg²⁺ voltage block (Jahr & Stevens 1990) alongside the fast AMPA-like channel. Because the block is relieved only by depolarization, NMDA acts as a coincidence detector and supplies the slow recurrent drive that sustains attractor states.

**Reward & Stress Learning (three-factor)** *(opt-in)*
A dopamine/cortisol reinforcement system. Set `enable_reward_learning=True` and STDP no longer edits weights directly — it lays down a slow **eligibility trace** that tags synapses with recent causal (pre→post) coactivation. A teaching signal then converts those tags into weight changes:

```python
brain.reward(2.0)          # dopamine  → POTENTIATE the active pathway (LTP)
brain.punish(1.5)          # cortisol  → DEPRESS  the active pathway (LTD)
brain.feedback(correct)    # reward if correct, cortisol if wrong
```

Because credit/blame lands only on the synapses that were *eligible*, the pathway a neuron just used gets reinforced when it leads to reward and weakened when it leads to punishment (Frémaux & Gerstner 2016; Izhikevich 2007). Dopamine is fast and phasic (Schultz 1997); **cortisol** is modelled as the slow stress hormone it is (HPA axis) — it depresses the responsible synapses and, when sustained, impairs further plasticity and can drive synaptic atrophy (Joëls & Krugers 2007). With the flag off (default), `reward()` keeps its original behavior of directly scaling STDP's LTP.

**Criticality & Firing-Regime Diagnostics**
A `CriticalityAnalyzer` reports the branching ratio (σ≈1 = critical) and neuronal-avalanche statistics (Beggs & Plenz 2003), and `SpikeStatistics` reports ISI irregularity (CV≈1 = Poisson-like) and the Fano factor (Softky & Koch 1993; Brunel 2000) — together a quick test of whether the network sits in the asynchronous-irregular, near-critical regime that real cortex occupies.

**Neuromodulator System**
Globally-broadcast chemical signals that retune the network:

| Modulator | Effect |
|---|---|
| `dopamine` | Scales LTP amplitude (reward-modulated STDP) |
| `acetylcholine` | Lowers synapse-formation threshold (attention / increased plasticity) |
| `serotonin` | Modulates membrane time constant (stability) |
| `norepinephrine` | Shifts firing threshold and noise amplitude (arousal) |
| `cortisol` | Stress hormone — depresses eligible synapses, impairs plasticity |

For richer experiments, [`neurochemistry.py`](src/neurochemistry.py) provides a full, extensible chemical system (see *Library Modules* below) that drops into `BrainNet` in place of the four-scalar default.

---

## Biophysical Options

Several mechanisms are configurable on `NeuronParams`. Adaptation is on by default (it is nearly universal in cortex and improves stability); the rest default **off** so existing experiments reproduce bit-for-bit until you opt in.

| Flag | Default | Effect |
|---|---|---|
| `enable_adaptation` | `True` | Spike-frequency adaptation current (AHP / M-current) |
| `conductance_based` | `False` | Conductance-based synapses with reversal potentials `E_exc` / `E_inh` (gives shunting inhibition) instead of current-based `g_e − g_i` |
| `enable_delays` | `False` | Per-axon conduction delays drawn from `[delay_min_ms, delay_max_ms]` |
| `enable_homeostasis` | `False` | Homeostatic synaptic scaling toward `target_rate_hz` |
| `enable_stp` | `False` | Short-term plasticity (`U_stp`, `tau_rec`, `tau_facil`); defaults to a facilitating synapse |
| `enable_nmda` | `False` | Slow voltage-gated NMDA conductance (`tau_nmda`, `nmda_ratio`, `Mg`) |
| `enable_exp` | `False` | AdEx exponential spike-initiation term (`delta_T`, `V_T`) — sharp upstroke + tonic/adapting/bursting firing patterns |
| `enable_istdp` | `False` | Inhibitory STDP (Vogels 2011) — inhibition learns to balance excitation toward `rho_target` Hz |
| `enable_gap` | `False` | Gap junctions / electrical synapses (`g_gap`); wired among FS interneurons by `cortex.py` |
| `enable_dendrite` | `False` | Two-compartment neuron: excitation (+NMDA) charges a separate active dendrite with regenerative spikes (`tau_d`, `g_couple`, `V_d_thresh`, `dend_plateau`) → supralinear dendritic computation |
| `noise_sqrt_dt` | `False` | Proper Euler–Maruyama (√dt) noise scaling — modest `noise_std` then drives realistic spontaneous activity |
| `sparse_synapses` | `False` | Edge-list connectivity backend (O(E) memory/compute) instead of the dense `[N,N]` matrix — scales past the few-thousand-neuron ceiling |
| `enable_reward_learning` | `False` | Three-factor reward/stress learning: eligibility traces gated by dopamine (`reward()`) and cortisol (`punish()`) — see below |

**Scaling.** The default dense `[N,N]` weight matrix is simple and fine to a few thousand neurons, but on an 8 GB GPU the `W`/`age` matrices alone are ~512 MB at N=8000 and grow as N². Set `sparse_synapses=True` for an edge-list backend whose memory and per-step cost scale with the number of *synapses*, not N² — verified to reproduce the dense backend's dynamics exactly (identical STDP updates; identical spike trains on matched connectivity). The growth cone's pairwise correlation is still O(N²) and is the next target to sparsify.

> **Correctness note (v1.1):** the STDP update was previously sign-inverted (it depressed pre-before-post pairs), making learning anti-Hebbian and contradicting the Bi & Poo rule cited above. It now potentiates pre-before-post and depresses post-before-pre, and traces are registered *after* the weight update (correct pair-based ordering). This changes the outcome of any run that relies on plasticity.

---

## Library Modules

The package is split so heavy users can compose and extend pieces independently:

| Module | Purpose |
|---|---|
| [`core.py`](src/core.py) | LIF neurons, synapses, STDP, growth cone, assemblies, oscillation/criticality analyzers, `BrainNet` orchestration |
| [`sparse_synapses.py`](src/sparse_synapses.py) | Edge-list connectivity backend for scaling past the dense `[N,N]` ceiling (`sparse_synapses=True`) |
| [`neurochemistry.py`](src/neurochemistry.py) | Extensible neurochemical system (below) |
| [`closed_loop.py`](src/closed_loop.py) | Closed-loop task harness — learning from self-generated feedback (below) |
| [`cortex.py`](src/cortex.py) | Cell types (fast-spiking interneurons) + cortical E–I microcircuit → gamma (below) |

### Neurochemistry

`neurochemistry.py` models neurochemicals as first-class objects with their own release/clearance kinetics. Every chemical influences the network by **pushing the five control axes** the simulator reads (`dopamine`, `serotonin`, `norepinephrine`, `acetylcholine`, `cortisol`), so a `Neurochemistry` object is a drop-in superset of the default `NeuromodulatorState` — and arbitrary new chemicals affect the dynamics without touching `core.py`.

```python
from core import BrainNet
from neurochemistry import default_neurochemistry, Neurochemical

brain = BrainNet(N=500, neurochem=default_neurochemistry())
brain.modulator.release('adenosine', 1.0)   # sleep pressure → suppresses arousal/attention
brain.modulator.release('cortisol', 1.5)    # acute stress
# add your own:
brain.modulator.add(Neurochemical('caffeine', baseline=0.0, tau=20000, kind='xenobiotic',
                                  effects={'norepinephrine': 0.4, 'acetylcholine': 0.2}))
```

The default palette models dopamine, serotonin, norepinephrine, acetylcholine and cortisol (primary), plus histamine, adenosine, melatonin, oxytocin, endorphin (secondary modulators of wake/sleep/stress) and glutamate/GABA/NO/endocannabinoid. Presets: `stressed()`, `drowsy()`, `aroused()`.

### Closed-Loop Learning (natural feedback)

`closed_loop.py` closes the reinforcement loop: the network's **own decoded output** decides whether it was right, and `brain.feedback(correct)` is applied automatically — reward (dopamine) if right, stress (cortisol) if wrong — so the synapses that produced the action are reinforced or weakened (R-STDP; Izhikevich 2007, Legenstein et al. 2008). Each trial *encodes* a stimulus into sensory neurons, lets the network *act*, *decodes* the most active motor group as its choice, *scores* it against the task, and *consolidates* via the eligibility-gated reward signal.

```python
from closed_loop import demo_conditioning
early, late, log = demo_conditioning(n_trials=150)   # ≈0.30 → 1.00 response rate
```

`demo_conditioning` (operant conditioning, Fetz 1969) reliably learns: the network is rewarded when its own target output crosses threshold, and reward-gated plasticity ratchets that pathway up until it responds on cue. Requires `enable_reward_learning=True`.

`demo_discrimination` learns a 2-alternative forced choice (climbing to **~0.85** accuracy) once three ingredients are combined: **winner-take-all** lateral inhibition between output groups (so only the winner is eligible), a dopamine **reward-prediction-error** baseline (so correct/wrong don't cancel), and a dedicated plastic **input→output projection** (so credit isn't buried in recurrent noise). It then shows a late instability typical of unregulated R-STDP — `enable_homeostasis=True` is the intended stabilizer.

> Two findings worth knowing. (1) **Reward-only vs. reward+punish:** because the learning signal is `M = (dopamine−1) − cortisol` and cortisol clears slowly, frequent errors keep cortisol elevated and *cancel* subsequent reward — a realistic "chronic stress blocks reward learning" effect, so simple conditioning uses positive reinforcement only. (2) For trial-by-trial RL the wrong-signal is better modeled as a fast dopamine *dip* (RPE) than as slow cortisol — see `feedback(..., use_cortisol=False)`.

### Structured Cortex

`cortex.py` replaces the homogeneous random soup with a model of cortex: distinct **cell types** (each with its own intrinsic dynamics — fast-spiking PV⁺ interneurons are fast and non-adapting, regular-spiking pyramidal cells are slow and strongly adapting) wired by the canonical **E–I microcircuit**, optionally in **columns**.

```python
from cortex import build_cortex, demo_gamma
brain = build_cortex(N=800, columns=4)
demo_gamma()   # drive the excitatory cells → a gamma-band rhythm emerges
```

The payoff is biological: fast feedback inhibition from FS interneurons generates **gamma oscillations via the PING mechanism** (Cardin et al. 2009) — measured by the `OscillationAnalyzer` as a dominant gamma band, with FS interneurons firing at ~160 Hz vs ~54 Hz for pyramidal cells. This is the first emergent rhythm a random network cannot produce. Per-neuron heterogeneity is exposed generally via `NeuronPopulation.set_cell_params(...)`.

See [`docs/RESULTS.md`](docs/RESULTS.md) for the full test record and [`docs/HARDWARE.md`](docs/HARDWARE.md) for the scaling / "what hardware runs a bare consciousness" analysis.

---

## What Makes This Different

Most "biologically inspired" networks are just MLPs with a renamed activation function. This network has no fixed topology — synapses are born, strengthened, and pruned entirely through dynamics. Thoughts are not labels or output logits; they are detected as **emergent synchrony patterns** within the network itself.

---

## Installation

The project is a pip-installable package (`bioneuron`). From the repo root:

```bash
pip install -e ohToBeAlive          # editable / development install
# or build distributables for PyPI:
pip install build twine
python -m build ohToBeAlive         # creates dist/*.whl and *.tar.gz
```

Dependencies: `torch>=2.0`, `numpy>=1.21` (plus `matplotlib` for the notebook visuals, via the `viz` extra). A console entry point is installed:

```bash
bioneuron version
bioneuron demo conditioning --trials 150
```

> The importable package is `bioneuron`; the source still lives in `src/` (mapped via `pyproject.toml`). If the name `bioneuron` is taken on PyPI, change `name` in `pyproject.toml`.

---

## Quickstart

```python
from bioneuron import BrainNet, default_neurochemistry   # or: from core import BrainNet (flat)

brain = BrainNet(N=300, neurochem=default_neurochemistry())

for t in range(5000):
    spikes, state = brain.step(dt=1e-4)

brain.reward(2.0)            # dopamine burst
brain.attend(1.8)            # acetylcholine → aggressive synapse seeking
print(brain.get_thoughts())  # current cell assemblies
```

---

## References

- Hodgkin & Huxley (1952) — Action potential biophysics
- Bi & Poo (1998) — Synaptic modification by correlated activity (STDP)
- Morrison, Diesmann & Gerstner (2008) — Phenomenological models of STDP (online pair rule)
- Hebb (1949) — Organization of Behavior (cell assemblies)
- Brette & Gerstner (2005) — Adaptive exponential integrate-and-fire model (spike-frequency adaptation)
- Turrigiano & Nelson (2004) — Homeostatic plasticity in the developing nervous system
- Tsodyks & Markram (1997); Mongillo, Barak & Tsodyks (2008) — Short-term plasticity; synaptic theory of working memory
- Jahr & Stevens (1990) — Voltage dependence of NMDA-activated currents (Mg²⁺ block)
- Beggs & Plenz (2003) — Neuronal avalanches / self-organized criticality
- Softky & Koch (1993); Brunel (2000) — Irregular firing & the asynchronous-irregular cortical state
- Buzsáki & Draguhn (2004) — Neuronal oscillations in cortical networks
- Cardin et al. (2009); Buzsáki & Wang (2012) — Fast-spiking interneurons and gamma (PING)
- Naud et al. (2008) — AdEx firing patterns; Vogels et al. (2011) — Inhibitory plasticity & E/I balance; Galarreta & Hestrin (1999) — Electrical synapses between interneurons
- Poirazi & Mel (2003); Larkum (2013); Polsky et al. (2004) — Dendritic computation, dendritic spikes, supralinear summation
- Schultz et al. (1997) — Dopamine reward prediction error
- Frémaux & Gerstner (2016); Izhikevich (2007); Legenstein et al. (2008) — Three-factor / reward-modulated STDP, eligibility traces, closed-loop reinforcement
- Joëls & Krugers (2007) — Stress, glucocorticoids (cortisol) and synaptic plasticity
- Saper et al. (2005); Porkka-Heiskanen et al. (1997) — Sleep–wake neurochemistry (adenosine, histamine, monoamines)
- Dale (1935) — Pharmacology and nerve endings (Dale's Law)
